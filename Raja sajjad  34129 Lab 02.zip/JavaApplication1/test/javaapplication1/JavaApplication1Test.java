/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author rmehmood.bscs14seecs
 */
public class JavaApplication1Test {
    
    public JavaApplication1Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of multiply method, of class JavaApplication1.
     */
    @Test
    public void testMultiply() {
        System.out.println("multiply");
        int[][] m1 = {{1,2,3}, 
                     {4,5,6}};
        int[][] m2 = {{4,5,6}, {7,8,9} , {10,11,12}};
        int[][] expResult = {{48,54,60},{111,126,141}};
        int[][] result = JavaApplication1.multiply(m1, m2);
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
