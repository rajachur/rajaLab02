/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import javaapplication1.Stras;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
/**
 *
 * @author test1
 */
public class Stressclass {
   public int[][]  A;
   public int[][]  B;
   Strassen s;
    
   @Test
    public void StrassenTestADD() {
       int[][] expected = new int[][]{
           {4,6},
           {8,5}
       };
       Assert.assertArrayEquals(s.add(A, B),expected);
    }
    @Test
    public void StrassenTestSUB() {
       int[][] expected = new int[][]{
           {2,2},
           {2,-3}
       };
       Assert.assertArrayEquals(s.sub(B, A),expected);
    }
     @Test
    public void StrassenTestProd() {
       int[][] expected = new int[][]{
           {13,6},
           {29,16}
       };
       Assert.assertArrayEquals(s.multiply(A, B),expected);
    }
    
   @Test
    public void StrassenTestPadding(){
        int [][] z = new int[][]{
            {1,2},
            {3,4},
            {5,6}
        };
        int [][]expected = new int[][]{
               {1,2,0,0},
                {3,4,0,0},
               {5,6,0,0},
                {0,0,0,0}
        };
      // Assert.assertArrayEquals(s.padding(z),expected);
   }
    
    @Test
    public void StrassenTestPower(){
      int expected = 2;
      assertEquals(s.nearestPowerofTwo(2),expected);
    }
    
    @Test
    public void StrassenTestOdd(){
        int [][] A = new int[][]{
            {1,2,3},
            {4,5,6},
            {1,5,6}
        };
        int [][] B = new int[][]{
            {5,7,6},
            {7,8,9},
            {1,2,7}
        };
        int [][] expected = new int[][]{
            {22,29,45},
            {61,80,111},
            {46,59,93}
        };
        Assert.assertArrayEquals(s.multiply(A, B),expected);
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
      A = new int[][]{
          {1,2},
          {3,4}
      };
      B = new int[][]{
          {3,4},
          {5,1}
        };
      s = new Strassen();
      
    };
    
    @After
    public void tearDown() {
    }

}
