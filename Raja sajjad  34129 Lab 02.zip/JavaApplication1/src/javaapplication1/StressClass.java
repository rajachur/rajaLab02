package JavaApplication1;

public class StressClass
{
   
    public void padding(int[][] A){
        int resize = nearestPowerofTwo(A.length);
        
        int[][] A1 = new int[resize][resize];
        
       
        
    }
    
    //Strassen Matrix for Multipication
    public int[][] multiply(int[][] A1, int[][] B1)
    {        
        int n = A1.length;
        int resize = nearestPowerofTwo(A1.length);
        int [][]A = new int[resize][resize];
        int [][]B = new int[resize][resize];
        
         for(int i=0;i<A1.length;i++){
            for(int j=0;j<A1[0].length;j++){
                A[i][j] = A1[i][j];
                B[i][j] = B1[i][j];
            }
        }
        
        int[][] product = new int[resize][resize];
        if (n == 1)
            product[0][0] = A[0][0] * B[0][0];
        else
        {
            int[][] A11 = new int[resize/2][resize/2];
            int[][] A12 = new int[resize/2][resize/2];
            int[][] A21 = new int[resize/2][resize/2];
            int[][] A22 = new int[resize/2][resize/2];
            int[][] B11 = new int[resize/2][resize/2];
            int[][] B12 = new int[resize/2][resize/2];
            int[][] B21 = new int[resize/2][resize/2];
            int[][] B22 = new int[resize/2][resize/2];
 
            /** Dividing matrix A into 4 halves **/
            divide(A, A11, 0 , 0);
            divide(A, A12, 0 , resize/2);
            divide(A, A21, resize/2, 0);
            divide(A, A22, resize/2, resize/2);
            /** Dividing matrix B into 4 halves **/
            divide(B, B11, 0 , 0);
            divide(B, B12, 0 , resize/2);
            divide(B, B21, resize/2, 0);
            divide(B, B22, resize/2, resize/2);
 
            /** 
              M1 = (A11 + A22)(B11 + B22)
              M2 = (A21 + A22) B11
              M3 = A11 (B12 - B22)
              M4 = A22 (B21 - B11)
              M5 = (A11 + A12) B22
              M6 = (A21 - A11) (B11 + B12)
              M7 = (A12 - A22) (B21 + B22)
            **/
 
            int [][] M1 = multiply(add(A11, A22), add(B11, B22));
            int [][] M2 = multiply(add(A21, A22), B11);
            int [][] M3 = multiply(A11, sub(B12, B22));
            int [][] M4 = multiply(A22, sub(B21, B11));
            int [][] M5 = multiply(add(A11, A12), B22);
            int [][] M6 = multiply(sub(A21, A11), add(B11, B12));
            int [][] M7 = multiply(sub(A12, A22), add(B21, B22));
 
            /**
              C11 = M1 + M4 - M5 + M7
              C12 = M3 + M5
              C21 = M2 + M4
              C22 = M1 - M2 + M3 + M6
            **/
            int [][] C11 = add(sub(add(M1, M4), M5), M7);
            int [][] C12 = add(M3, M5);
            int [][] C21 = add(M2, M4);
            int [][] C22 = add(sub(add(M1, M3), M2), M6);
 
            /** join 4 halves into one result matrix **/
            join(C11, product, 0 , 0);
            join(C12, product, 0 , resize/2);
            join(C21, product, resize/2, 0);
            join(C22, product, resize/2, resize/2);
            
            
        }
        int [][] prod = new int[n][n];
            for(int i=0;i<n;i++){
                for(int j=0;j<n;j++)
                    prod[i][j] = product[i][j];  
                
            }
        /** return result **/    
        return prod;
    }
    /** Funtion to sub two matrices **/
    public int[][] sub(int[][] A, int[][] B)
    {
        int n = A.length;
        int[][] C = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                C[i][j] = A[i][j] - B[i][j];
        return C;
    }
    public int[][] add(int[][] A, int[][] B)
    {
        int n = A.length;
        int[][] C = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                C[i][j] = A[i][j] + B[i][j];
        return C;
    }
    
    public int nearestPowerofTwo(int n){
          int log2 = (int) Math.ceil(Math.log(n) / Math.log(2));
          return (int) Math.pow(2, log2);
    }

    public void divide(int[][] P, int[][] C, int iB, int jB) 
    {
        for(int i1 = 0, i2 = iB; i1 < C.length; i1++, i2++)
            for(int j1 = 0, j2 = jB; j1 < C.length; j1++, j2++)
                C[i1][j1] = P[i2][j2];
    }
    public void join(int[][] C, int[][] P, int iB, int jB) 
    {
        for(int i1 = 0, i2 = iB; i1 < C.length; i1++, i2++)
            for(int j1 = 0, j2 = jB; j1 < C.length; j1++, j2++)
                P[i2][j2] = C[i1][j1];
    }
    public static void main(String[] args){
        StressClass s = new StressClass();
        int [][] A = new int[][]{
            {1,2,3},
            {4,5,6},
            {1,5,6}
        };
        int [][] B = new int[][]{
            {5,7,6},
            {7,8,9},
            {1,2,7}
        };
        int [][] c = s.multiply(A, B);
        int z=2;
    }
  
}