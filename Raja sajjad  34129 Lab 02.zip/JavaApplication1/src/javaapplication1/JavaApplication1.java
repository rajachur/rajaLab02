/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author rmehmood.bscs14seecs
 */
 public class JavaApplication1 {

  
  public static int[][] multiply(int[][] m1, int[][] m2) {    
    int m1rows = m1.length; /* rows of first matrix*/
   
    int m1cols = m1[0].length; /* columns of first matrix*/
    int m2rows = m2.length; /* columns of 2nd matrix*/
    int m2cols = m2[0].length; /* columns of 2nd matrix*/
    if (m1cols != m2rows) /* a check to see weather columns of first matrix is equal to 2nd matrix or not as this is very important*/
      throw new IllegalArgumentException("matrices don't match: " + m1cols + " != " + m2rows); /* if not equal then throw exception*/
    int[][] result = new int[m1rows][m2cols]; /*array to store result*/

    // multiplication logic
    for (int i=0; i<m1rows; i++)
      for (int j=0; j<m2cols; j++)
        for (int k=0; k<m1cols; k++)
        result[i][j] += m1[i][k] * m2[k][j];

    return result;
  }
  
        
    }
    

